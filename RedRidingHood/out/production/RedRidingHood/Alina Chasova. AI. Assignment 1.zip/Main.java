import java.io.FileNotFoundException;

/**
 * Created by AlinaCh on 12.09.2017.
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        Game g = new Game();
    }
}
